import Logo from "@/assets/images/logo.png"
import Link from "next/link"

const NavBar = () => {
  return (
    <div className="bg-black-header text-white px-4">
      <header>
        <nav className="flex h-20 items-center justify-between">

        <a href="#" className="max-w-[90px] w-[30%]">
                    <img 
                    className="block w-full"
                    src={Logo.src} alt="" />
                </a>

        <ul className="fixed inset-0 px-[5%] 
                grid gap-6 auto-rows-max 
                content-center justify-items-center clip-circle-0
                peer-checked/menu:clip-circle-full bg-menu-color
                transition-[clip-path] duration-500
                md:clip-circle-full md:relative
                md:grid-flow-col md:p-0 md:bg-transparent
                ">
                    <li className=" px-3 py-2 hover:bg-white hover:rounded-xl hover:text-black">
                        
                        <Link href="/">Home</Link>
                    </li>
                    <li className=" px-3 py-2 hover:bg-white hover:rounded-xl hover:text-black">
                        
                        <Link href="/nosotros">Sobre nosotros</Link>
                    </li>
                    <li className=" px-3 py-2 hover:bg-white hover:rounded-xl hover:text-black">
                        <Link href="/servicios">Servicios</Link>
                    </li>

                    <li className="bg-white rounded-xl text-black px-3 py-2">
                        <Link href="/contacto">Contacto</Link>
                    </li>
                </ul>
                
        </nav>
      </header>
    </div>
  )
}

export default NavBar