
const Footer = () => {
  return (
    <>
    <section className="bg-white pl-6 pt-6">
    <div >Footer</div>
    <div>LOGO</div>
    <div className="flex gap-2 ">
        <a href="">Inicio</a>
        <a href="">Sobre nosotros</a>
        <a href="">Servicios</a>
        <a href="">Contacto</a>
    </div>
    </section>
    </>
    
  )
}

export default Footer