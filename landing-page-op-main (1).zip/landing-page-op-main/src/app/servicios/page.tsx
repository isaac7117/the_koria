import React from 'react'

const Servicios = () => {
  return (
    <div>Servicios</div>
  )
}

export default Servicios