
export default function Home() {
  return (
    <div className="">
      <p>Este es el home por defecto</p>
    </div>
  );
}
